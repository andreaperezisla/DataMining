import re
import os
import ftplib
import math
import ast

k = 15

def distanciaeuclidea(x1, x2, y1, y2):
    int(x1)
    int(x2)
    int(y1)
    int(y2)
    dist = math.sqrt(math.pow(x1 - x2, 2) + math.pow(y1 - y2, 2))
    return dist

def decision(closest_label):
    c_plus = 0
    c_minus = 0
    for label in closest_labels:
        if label == '-1':
            c_minus += 1
        elif label == '+1':
            c_plus += 1
    if c_plus > c_minus:
        print('+1')
    else:
        print('-1')



closest = []

training_data = [] # [((x, y, z), label), ...]

with open('transition','r') as f:
    lines = f.readlines()
    for line in lines:
        line = ast.literal_eval(line)
        numpalabras = line[1]
        pesop = line[2]
        labeltraining = line[3]
        point = (numpalabras, pesop)
        training_data.append((point, labeltraining))
        #coger valores y meterlos en training_data
        #point = (x, y, z)
        #label = a
        #training_data.append((point, a))


test_data = [] # [((x, y, z), None), ...]

with open('cleanedtest', 'r') as f1:
    for linee in f1.readlines():
        linee = ast.literal_eval(linee)
        numpalabrastest = linee[1]
        pesoptest = linee[2]
        labeltest = None
        point = (numpalabrastest, pesoptest)
        test_data.append((point, labeltest))


predictions = []

for test in test_data:
    #point = test[0]
    (x1, y1) = test[0]

    closest = []

    for data in training_data:
        (x2, y2) = data[0]
        label = data[1]

        # Calcular distancia
        distancia = distanciaeuclidea(x1, x2, y1, y2)
        closest.append((distancia, label))

    closest.sort(key=lambda tup: tup[0])
    kclosest = closest[:k]
    #print(kclosest)
    closest_labels = [c[1] for c in kclosest]
    #print(closest_labels)

    c_plus = 0
    c_minus = 0

    #print(closest_labels)

    decision(closest_labels)

    #else:
    #    print(None)





#import ast
#x = ast.literal_eval(x)





