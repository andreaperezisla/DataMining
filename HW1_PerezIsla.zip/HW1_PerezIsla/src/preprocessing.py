import io
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import numpy as np
import matplotlib.pyplot as plt
import math

vecinos = [0 for x in range(12)]

def contadorpalabras(linea):
    return len(linea)

def borrapalabras(linea):
    reviewfiltrada3 = [word for word in review if len(word) >= 3]
    return reviewfiltrada3

#Hacer lista de stopwords
listaStop = set(stopwords.words('english'))

#Funcion que calcula el peso de la review en funcion de las palabras que hay dentro

def pesopalabras(perfect):
    peso = 0
    for palabra in perfect:
        if palabra == "amazing" or palabra == "amazement":
            peso += 11 + cuantificador(palabra, peso)
        if palabra == "excellent" or palabra == "wonderful" or palabra == "success" or palabra == "saver":
            peso += 10 + cuantificador(palabra, peso)
        if palabra == "love" or palabra == "loves" or palabra == "loved" or palabra == "loving":
            peso += 9 + cuantificador(palabra, peso)
        if palabra == "recommend" or palabra == "recommends" or palabra == "recommended" or palabra == "recommending":
            peso += 9 + cuantificador(palabra, peso)
        if palabra == "helpful" or palabra == "useful" or palabra == "saver" or palabra == "good":
            peso += 8 + cuantificador(palabra, peso)
        if palabra == "help" or palabra == "helps" or palabra == "helping" or palabra == "helped":
            peso += 7 + cuantificador(palabra, peso)
        if palabra == "new" or palabra == "nice" or palabra == "easy" or palabra == "ease" or palabra == "easier":
            peso += 7 + cuantificador(palabra, peso)
        if palabra == "perfect" or palabra == "happy" or palabra == "happiness":
            peso += 6 + cuantificador(palabra, peso)
        if palabra == "practical" or palabra == "enjoy" or palabra == "enjoyed":
            peso += 5 + cuantificador(palabra, peso)
        if palabra == "worst" or palabra == "worse" or palabra == "bad" or palabra == "error" or palabra == "err":
            peso -= 10 + cuantificador(palabra, peso)
        if palabra == "germy" or palabra == "germs" or palabra == "garbage" or palabra == "never":
            peso -= 9 + cuantificador(palabra, peso)
        if palabra == "hate" or palabra == "hates" or palabra == "hated" or palabra == "stink" or palabra == "stinks":
            peso -= 8 + cuantificador(palabra, peso)
        if palabra == "pilling" or palabra == "shedding" or palabra == "issue" or palabra == "issues":
            peso -= 8 + cuantificador(palabra, peso)
        if palabra == "annoy" or palabra == "annoys" or palabra == "annoyed" or palabra == "annoyed":
            peso -= 8 + cuantificador(palabra, peso)
        if palabra == "mistake" or palabra == "break" or palabra == "broke" or palabra == "broken":
            peso -= 7 + cuantificador(palabra, peso)
        if palabra == "waste" or palabra == "return" or palabra == "re-order" or palabra == "wasteful":
            peso -= 7 + cuantificador(palabra, peso)
        if palabra == "back" or palabra == "slow" or palabra == "negative" or palabra == "awful":
            peso -= 7 + cuantificador(palabra, peso)
        if palabra == "bother" or palabra == "bothers" or palabra == "dangerous" or palabra == "difficult" or palabra == "nervous":
            peso -= 6 + cuantificador(palabra, peso)
        if palabra == "disappoint" or palabra == "disappoints" or palabra == "disappointed":
            peso -= 6 + cuantificador(palabra, peso)
        if palabra == "disappointment" or palabra == "expensive":
            peso -= 6 + cuantificador(palabra, peso)
        if palabra == "useless" or palabra == "problem" or palabra == "problems" or palabra == "unfortunately" or palabra == "shrunk":
            peso -= 5 + cuantificador(palabra, peso)
        if palabra == "junk" or palabra == "junks" or palabra == "suck" or palabra == "sucks" or palabra == "odor" or palabra == "odors":
            peso -= 5 + cuantificador(palabra, peso)
    return peso


#COMPROBAR SI HACE BIEN LO DE PESOBUENO PORQUE ANTES ESTABA PUESTO SIN EL + Y CON EL RETURN PESOBUENO

def cuantificador(palabra, peso):
    if perfect.index(palabra) - 1 == ("very" or "great" or "huge" or "big" or "nasty" or "stinky" or "quite") and peso < 0:
        peso -= 20
    elif perfect.index(palabra) -1 == ("pretty" or "terribly" or "incredibly" or "extremely" or "total" or "went") and peso < 0:
        peso -= 16
    elif perfect.index(palabra) -1 == ("beyond" or "hugely" or "were" or "more" or "really" or "rather" or "absolute") and peso < 0:
        peso -= 15
    elif perfect.index(palabra) -1 == "just" and peso < 0:
        peso -= 12
    elif perfect.index(palabra) - 1 == ("very" or "great" or "huge" or "big") and peso > 0:
        peso += 20
    elif perfect.index(palabra) - 1 == ("never" or "little" or "bit" or "not") and peso < 0:   #aqui es peso menor que cero, son opiniones que parecen negativas pero son positivas con estas palabras por delante
        peso += 15
    elif perfect.index(palabra) - 1 == ("get" or "gets" or "wont" or "doesnt") and peso > 0:
        peso += 14
    else:
        return peso


#Leer las lineas del train-PROGRAMA PRINCIPAL
with open('1535553470_0053222_train_file.data', 'r', encoding='utf8') as f:
    lineas = f.readlines()
    for linea in lineas:

        minlinea = linea.lower()
        separalineas = minlinea.split()
        label = separalineas[0]
        review = separalineas[1:]
        reviewfiltrada = [word for word in review if word not in listaStop]
        reviewfiltradalimpia = [''.join(e for e in string if e.isalnum()) for string in reviewfiltrada]
        perfect = borrapalabras(reviewfiltradalimpia)


        indice = lineas.index(linea)
        pesos = pesopalabras(perfect)
        longlinea = len(linea)
        helouda = [indice, longlinea, pesos, label]
        #AQUI LLEGA EL PROGRAMA
        print(helouda)
