Installing
pip install numpy scipy scikit-learn

Running
python3 knn_classification.py
