from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_selection import SelectFromModel

import numpy as np
import random

def read_training(fname):
    fo = open(fname, "r")
    lines = fo.readlines()
    fo.close()
    m = np.zeros((len(lines), 100000))
    labels = []
    for i,line in enumerate(lines):
        label = line[:1]
        data = line[1:]
        for str_num in data.split():
            index = int(str_num)
            m[i][index-1] = 1
        labels.append(int(label))
    return (m,labels)

def read_test(fname):
    fo = open(fname, "r")
    lines = fo.readlines()
    fo.close()
    m = np.zeros((len(lines), 100000))
    for i,line in enumerate(lines):
        for str_num in line.split():
            index = int(str_num)
            m[i][index-1] = 1
    return m
training_set = read_training('1537190286_493186_train_drugs.data')
test_set = read_test('1537190286_50615_test.data')
X = training_set[0] #training_set of vectors before being reduced
y = training_set[1] #target array (label values of each vector)

# %71 on miner
clf = DecisionTreeClassifier(class_weight="balanced")
clf.fit(X, y)

# performs feature selection
model = SelectFromModel(clf, prefit=True)
RD_X = model.transform(X)
print(RD_X.shape)
RD_test  = model.transform(test_set)

# ****** printing results to file
results = clf.fit(RD_X,y).predict(RD_test)
output_file = str('test'+str(random.randint(1,1001))+'.dat')
file = open(output_file,'w')
for i in range(0,len(results)):
    file.write(str(results[i]) + '\n')
print('Finished! Results in ➡️',output_file)
