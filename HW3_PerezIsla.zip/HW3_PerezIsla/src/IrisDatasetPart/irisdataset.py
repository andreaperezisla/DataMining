

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import ast
import math
import random

data = []
x = []
pp = ''
distt = []
label = []
listapuntos = [[5.0, 1.6, 0.4, None], [5.9, 4.2, 1.5, None], [6.7, 5.7, 2.1, None]]
k1 = [5.0, 1.6, 0.4, '1'] #mirar si poner aqui el label como cuarto componente
k2 = [5.9, 4.2, 1.5, '2'] #he cambiado este punto, el primero me daba 0,56 de eficiencia, la segunda opcion 7.6
k3 = [6.7, 5.7, 2.1, '3']


def distanciaeuclidea(calculos, k1, k2, k3):
    for dato in calculos:
        x1 = dato[0]
        y1 = dato[1]
        z1 = dato[2]
        #abajo punto central 1
        xk1 = k1[0]
        yk1 = k1[1]
        zk1 = k1[2]
        #abajo punto central 2
        xk2 = k2[0]
        yk2 = k2[1]
        zk2 = k2[2]
        #abajo punto central 3
        xk3 = k3[0]
        yk3 = k3[1]
        zk3 = k3[2]

        distk1 = math.sqrt(math.pow(x1 - xk1, 2) + math.pow(y1 - yk1, 2) + math.pow(z1 - zk1, 2))
        distk2 = math.sqrt(math.pow(x1 - xk2, 2) + math.pow(y1 - yk2, 2) + math.pow(z1 - zk2, 2))
        distk3 = math.sqrt(math.pow(x1 - xk3, 2) + math.pow(y1 - yk3, 2) + math.pow(z1 - zk3, 2))
        distans = [distk1, distk2, distk3]
        distt.append(distans)

    return distt

def decision(distancias, label):
    for d in distancias:
        if (d[0] < d[1]) and (d[0] < d[2]):
            #crear variable que almacene el grupo al que pertenece y hacer append con label
            pp = '1'
            label.append(pp)
        if (d[1] < d[0]) and (d[1] < d[2]):
            pp = '2'
            label.append(pp)
        if (d[2] < d[0]) and (d[2] < d[1]):
            pp = '3'
            label.append(pp)
    return label





with open('1538576435_7139187_iris_new.data', 'r') as f:
    lines = f.readlines()
    for line in lines:
        gline = line.split()
        sepallength = float(gline[0])
        #sepalwidth = float(gline[1])
        petallength = float(gline[2])
        petalwidth = float(gline[3])
        data = [sepallength,petallength, petalwidth, None]
        x.append(data)

calculos = [dato for dato in x if dato not in listapuntos]
#calculos contiene los puntos menos los centrales!
distancias = distanciaeuclidea(calculos, k1, k2, k3)
resultado = decision(distancias, label)

output_file = str('test'+str(random.randint(1, 1001))+'.dat')
file = open(output_file,'w')
for i in range(0,len(resultado)):
    file.write(str(resultado[i]) + '\n')
print('Finished! Results in ➡️',output_file)



