import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import ast


data = []
x = []
y = []
z = []
with open('1538576435_7139187_iris_new.data', 'r') as f:
    lines = f.readlines()
    for line in lines:
        gline = line.split()
        sepallength = float(gline[0])
        #sepalwidth = float(gline[1])
        petallength = float(gline[2])
        petalwidth = float(gline[3])
        #data = [sepallength, sepalwidth, petallength, petalwidth, None]
        x.append(sepallength)
        y.append(petalwidth)
        z.append(petallength)

fig = plt.figure()
ax = Axes3D(fig)
ax.scatter(x, y, z, marker='p')
plt.show()


