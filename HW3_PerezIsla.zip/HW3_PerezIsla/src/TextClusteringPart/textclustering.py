import matplotlib.pyplot as plt
import math
import random

distt = []
x = []
y = []
label = []
pp = ''
k = 0
j = 0

listapuntos = [[9.0, 9, None], [100.0, 149, None], [210.0, 419, None], [379.0, 542, None], [535.0, 1052, None], [744.0, 1461, None], [1007.0, 2058, None]]
k1 = [9.0, 9, '1'] #mirar si poner aqui el label como cuarto componente
k2 = [100.0, 149, '2'] #he cambiado este punto, el primero me daba 0,56 de eficiencia, la segunda opcion 7.6
k3 = [210.0, 419, '3']
k4 = [379.0, 542, '4']
k5 = [535.0, 1052, '5']
k6 = [744.0, 1461, '6']
k7 = [1007.0, 2058, '7']


def distanciaeuclidea(calculos, k1, k2, k3, k4, k5, k6, k7):
    for dato in calculos:
        x1 = dato[0]
        y1 = dato[1]
        #abajo punto central 1
        xk1 = k1[0]
        yk1 = k1[1]
        #abajo punto central 2
        xk2 = k2[0]
        yk2 = k2[1]
        #abajo punto central 3
        xk3 = k3[0]
        yk3 = k3[1]
        #abajo punto central 4
        xk4 = k4[0]
        yk4 = k4[1]
        #abajo punto central 5
        xk5 = k5[0]
        yk5 = k5[1]
        #abajo punto central 6
        xk6 = k6[0]
        yk6 = k6[1]
        #abajo punto central 7
        xk7 = k7[0]
        yk7 = k7[1]

        distk1 = math.sqrt(math.pow(x1 - xk1, 2) + math.pow(y1 - yk1, 2))
        distk2 = math.sqrt(math.pow(x1 - xk2, 2) + math.pow(y1 - yk2, 2))
        distk3 = math.sqrt(math.pow(x1 - xk3, 2) + math.pow(y1 - yk3, 2))
        distk4 = math.sqrt(math.pow(x1 - xk4, 2) + math.pow(y1 - yk4, 2))
        distk5 = math.sqrt(math.pow(x1 - xk5, 2) + math.pow(y1 - yk5, 2))
        distk6 = math.sqrt(math.pow(x1 - xk6, 2) + math.pow(y1 - yk6, 2))
        distk7 = math.sqrt(math.pow(x1 - xk7, 2) + math.pow(y1 - yk7, 2))

        distans = [distk1, distk2, distk3, distk4, distk5, distk6, distk7]
        distt.append(distans)

    return distt

def decision(distancias, label):
    for d in distancias:
        if (d[0] < d[1]) and (d[0] < d[2]) and (d[0] < d[3]) and (d[0] < d[4]) and (d[0] < d[5]) and (d[0] < d[6]):
            #crear variable que almacene el grupo al que pertenece y hacer append con label
            pp = '1'
            label.append(pp)
        if (d[1] < d[0]) and (d[1] < d[2]) and (d[1] < d[3]) and (d[1] < d[4]) and (d[1] < d[5]) and (d[1] < d[6]):
            pp = '2'
            label.append(pp)
        if (d[2] < d[0]) and (d[2] < d[1]) and (d[2] < d[3]) and (d[2] < d[4]) and (d[2] < d[5]) and (d[2] < d[6]):
            pp = '3'
            label.append(pp)
        if (d[3] < d[0]) and (d[3] < d[1]) and (d[3] < d[2]) and (d[3] < d[4]) and (d[3] < d[5]) and (d[3] < d[6]):
            pp = '4'
            label.append(pp)
        if (d[4] < d[0]) and (d[4] < d[1]) and (d[4] < d[2]) and (d[4] < d[3]) and (d[4] < d[5]) and (d[4] < d[6]):
            pp = '5'
            label.append(pp)
        if (d[5] < d[0]) and (d[5] < d[1]) and (d[5] < d[2]) and (d[5] < d[3]) and (d[5] < d[4]) and (d[5] < d[6]):
            pp = '6'
            label.append(pp)
        if (d[6] < d[0]) and (d[6] < d[1]) and (d[6] < d[2]) and (d[6] < d[3]) and (d[6] < d[4]) and (d[6] < d[5]):
            pp = '7'
            label.append(pp)
    return label





with open('1538577415_6724253_new_input.dat', 'r') as f:
    lines = f.readlines()
    for line in lines:
        gline = line.split()
        for i in range(0,len(gline)):
            if i % 2 != 0:
                j = j + int(gline[i])
        k = len(gline)/2
        data = [k, j, None]
        x.append(data)
        j=0
        k=0

calculos = [dato for dato in x if dato not in listapuntos]
distancias = distanciaeuclidea(calculos, k1, k2, k3, k4, k5, k6, k7)
resultado = decision(distancias, label)

output_file = str('test'+str(random.randint(1, 1001))+'.dat')
file = open(output_file,'w')
for i in range(0,len(resultado)):
    file.write(str(resultado[i]) + '\n')
print('Finished! Results in ➡️',output_file)
